<!DOCTYPE html>
<html>
<head><title>KennetFx</title></head>
<body>
<h1>Welcome to KennetFx Forex Investment</h1>
</body>
</html>