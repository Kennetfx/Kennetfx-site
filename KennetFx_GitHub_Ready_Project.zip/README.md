# KennetFx Website

This is a Laravel-based Forex Investment website for KennetFx. Deploy using Render or other Laravel-capable hosts.

## Setup Steps
1. Clone repo to your Render or local Laravel environment
2. Run `composer install`
3. Set up `.env` and `php artisan key:generate`
4. Run `php artisan migrate`
5. Use `php artisan serve` to test locally